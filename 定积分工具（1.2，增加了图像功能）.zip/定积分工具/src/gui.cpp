#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string>
#include <sstream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <clocale>

#include "parser.h"
#include "integrator.h"

// ---------------------------------------------------------------------------
//  UTF-8 <-> UTF-16  conversion helpers
// ---------------------------------------------------------------------------
static std::wstring UTF8ToWide(std::string_view s) {
    if (s.empty()) return {};
    int len = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring ws(len, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &ws[0], len);
    return ws;
}

static std::string WideToUTF8(std::wstring_view ws) {
    if (ws.empty()) return {};
    int len = WideCharToMultiByte(CP_UTF8, 0, ws.data(), (int)ws.size(), nullptr, 0, nullptr, nullptr);
    std::string s(len, '\0');
    WideCharToMultiByte(CP_UTF8, 0, ws.data(), (int)ws.size(), &s[0], len, nullptr, nullptr);
    return s;
}

// ---------------------------------------------------------------------------
//  Control IDs
// ---------------------------------------------------------------------------
enum Ctrl : int {
    ID_EXPR       = 101,
    ID_LOWER      = 102,
    ID_UPPER      = 103,
    ID_METHOD     = 104,
    ID_TOL        = 105,
    ID_COMPUTE    = 106,
    ID_RESULT     = 107,
    ID_EVALS      = 108,
    ID_GRAPH      = 109,
    ID_SEPARATOR  = 110,
};

// ---------------------------------------------------------------------------
//  Window layout constants  (default client area = 520 x 580, min 400 x 450)
// ---------------------------------------------------------------------------
static constexpr int DEF_W   = 520;
static constexpr int DEF_H   = 580;
static constexpr int MIN_W   = 400;
static constexpr int MIN_H   = 450;
static constexpr int MX      = 16;
static constexpr int MY      = 12;
static constexpr int LH      = 22;
static constexpr int EH      = 26;
static constexpr int BH      = 34;
static constexpr int GAP     = 6;
static constexpr int LW      = 120;

static constexpr int R1 = MY;
static constexpr int R2 = R1 + LH + GAP;
static constexpr int R3 = R2 + LH + GAP;
static constexpr int R4 = R3 + LH + GAP;
static constexpr int R5 = R4 + LH + GAP;
static constexpr int R6 = R5 + LH + GAP + 4;
static constexpr int R7 = R6 + BH + GAP + 8;
static constexpr int R8 = R7 + 10;
static constexpr int R9 = R8 + LH + 2;

static constexpr int GRAPH_Y = R9 + 12;

static inline int EditWidth(int clientW) { return clientW - 2 * MX - LW - GAP; }
static inline int FullWidth(int clientW) { return clientW - 2 * MX; }

// ---------------------------------------------------------------------------
//  Plot data shared between DoCompute and the graph paint handler
// ---------------------------------------------------------------------------
struct PlotState {
    bool valid = false;
    double a = 0, b = 1;
    IntegrationMethod method = IntegrationMethod::Adaptive;
    int nViz = 20;

    std::vector<double> curveX, curveY;   // dense samples for smooth curve
    std::vector<double> vizX, vizY;       // coarse samples for method overlay
    double yMin = 0, yMax = 1;
    double result = 0;
};

static PlotState g_plot;

// ---------------------------------------------------------------------------
//  Animation state for step-by-step drawing
// ---------------------------------------------------------------------------
struct AnimState {
    bool active = false;
    int step = 0;
    static constexpr int TOTAL = 55;
    UINT_PTR timerId = 0;
};
static AnimState g_anim;

// ---------------------------------------------------------------------------
//  Forward declarations
// ---------------------------------------------------------------------------
static LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
static LRESULT CALLBACK GraphWndProc(HWND, UINT, WPARAM, LPARAM);
static void     DoCompute(HWND hWnd);
static void     CentreWindow(HWND hWnd, int cx, int cy);
static void     CreateLabel(HWND parent, const wchar_t* text, int x, int y, int w, int h, int id);
static HWND     CreateEdit(HWND parent, int x, int y, int w, int h, int id);
static HWND     CreateCombo(HWND parent, int x, int y, int w, int h, int id);

// ---------------------------------------------------------------------------
//  Entry point
// ---------------------------------------------------------------------------
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow) {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    INITCOMMONCONTROLSEX icc = { sizeof(icc), ICC_STANDARD_CLASSES };
    InitCommonControlsEx(&icc);

    // Register main window class
    WNDCLASSEX wc = {};
    wc.cbSize        = sizeof(wc);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = L"IntegralCalcClass";
    if (!RegisterClassEx(&wc)) return 1;

    // Register graph child window class
    WNDCLASSEX gwc = {};
    gwc.cbSize        = sizeof(gwc);
    gwc.style         = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
    gwc.lpfnWndProc   = GraphWndProc;
    gwc.hInstance     = hInst;
    gwc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    gwc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
    gwc.lpszClassName = L"IntegralGraph";
    if (!RegisterClassEx(&gwc)) return 1;

    HWND hWnd = CreateWindowEx(
        0, L"IntegralCalcClass", L"定积分计算器",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_THICKFRAME | WS_MAXIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, DEF_W + 16, DEF_H + 39,
        nullptr, nullptr, hInst, nullptr
    );
    if (!hWnd) return 1;

    CentreWindow(hWnd, DEF_W + 16, DEF_H + 39);
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}

// ---------------------------------------------------------------------------
//  Main window procedure
// ---------------------------------------------------------------------------
static LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE:
    {
        HFONT hFont = CreateFont(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                 DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                 CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                 DEFAULT_PITCH, L"Microsoft YaHei");

        int ew = EditWidth(DEF_W);
        int fw = FullWidth(DEF_W);

        CreateLabel(hWnd, L"被积函数  f(x) =", MX, R1, LW, LH, 0);
        HWND hExpr = CreateEdit(hWnd, MX + LW + GAP, R1 - 2, ew, EH, ID_EXPR);
        (void)hExpr;

        CreateLabel(hWnd, L"积分下限  a =", MX, R2, LW, LH, 0);
        CreateEdit(hWnd, MX + LW + GAP, R2 - 2, ew, EH, ID_LOWER);

        CreateLabel(hWnd, L"积分上限  b =", MX, R3, LW, LH, 0);
        CreateEdit(hWnd, MX + LW + GAP, R3 - 2, ew, EH, ID_UPPER);

        CreateLabel(hWnd, L"计算方法", MX, R4, LW, LH, 0);
        HWND hMethod = CreateCombo(hWnd, MX + LW + GAP, R4 - 2, ew, EH, ID_METHOD);
        ComboBox_AddString(hMethod, L"Adaptive Simpson  (自适应)");
        ComboBox_AddString(hMethod, L"Simpson 1/3  (辛普森)");
        ComboBox_AddString(hMethod, L"Trapezoidal  (梯形法)");
        ComboBox_SetCurSel(hMethod, 0);

        CreateLabel(hWnd, L"精度控制 (容差)", MX, R5, LW, LH, 0);
        CreateEdit(hWnd, MX + LW + GAP, R5 - 2, ew, EH, ID_TOL);
        SetWindowText(GetDlgItem(hWnd, ID_TOL), L"1e-8");

        CreateWindowEx(
            0, L"BUTTON", L"计算定积分",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            MX, R6 - 2, fw, BH,
            hWnd, (HMENU)(INT_PTR)ID_COMPUTE, GetModuleHandle(nullptr), nullptr
        );

        CreateWindowEx(
            0, L"STATIC", L"",
            WS_CHILD | WS_VISIBLE | SS_ETCHEDHORZ,
            MX, R7, fw, 2,
            hWnd, (HMENU)(INT_PTR)ID_SEPARATOR, GetModuleHandle(nullptr), nullptr
        );

        CreateLabel(hWnd, L"结果:  (等待计算)", MX, R8, fw, LH + 4, ID_RESULT);

        CreateLabel(hWnd, L"", MX, R9, fw, LH, ID_EVALS);

        // Create graph child window
        int graphH = DEF_H - GRAPH_Y - MY;
        CreateWindowEx(
            WS_EX_CLIENTEDGE, L"IntegralGraph", L"",
            WS_CHILD | WS_VISIBLE,
            MX, GRAPH_Y, fw, graphH,
            hWnd, (HMENU)(INT_PTR)ID_GRAPH, GetModuleHandle(nullptr), nullptr
        );

        // Apply default font to all children
        if (hFont) {
            HWND child = nullptr;
            while ((child = FindWindowEx(hWnd, child, nullptr, nullptr))) {
                SendMessage(child, WM_SETFONT, (WPARAM)hFont, TRUE);
            }
        }

        HFONT hResultFont = CreateFont(22, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                                       DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                       CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                       DEFAULT_PITCH, L"Microsoft YaHei");
        if (hResultFont) {
            SendMessage(GetDlgItem(hWnd, ID_RESULT), WM_SETFONT, (WPARAM)hResultFont, TRUE);
        }

        SetFocus(hExpr);
        return 0;
    }

    case WM_COMMAND:
        if (HIWORD(wParam) == BN_CLICKED && LOWORD(wParam) == ID_COMPUTE) {
            DoCompute(hWnd);
        }
        break;

    case WM_SIZE:
    {
        int cw = LOWORD(lParam);
        int ch = HIWORD(lParam);
        if (cw == 0 || ch == 0) break;

        int ew = EditWidth(cw);
        if (ew < 60) ew = 60;
        int fw = FullWidth(cw);
        if (fw < 60) fw = 60;

        SetWindowPos(GetDlgItem(hWnd, ID_EXPR),    nullptr, 0, 0, ew, EH, SWP_NOZORDER | SWP_NOMOVE);
        SetWindowPos(GetDlgItem(hWnd, ID_LOWER),   nullptr, 0, 0, ew, EH, SWP_NOZORDER | SWP_NOMOVE);
        SetWindowPos(GetDlgItem(hWnd, ID_UPPER),   nullptr, 0, 0, ew, EH, SWP_NOZORDER | SWP_NOMOVE);
        SetWindowPos(GetDlgItem(hWnd, ID_METHOD),  nullptr, 0, 0, ew, EH + 120, SWP_NOZORDER | SWP_NOMOVE);
        SetWindowPos(GetDlgItem(hWnd, ID_TOL),     nullptr, 0, 0, ew, EH, SWP_NOZORDER | SWP_NOMOVE);
        SetWindowPos(GetDlgItem(hWnd, ID_COMPUTE), nullptr, 0, 0, fw, BH, SWP_NOZORDER | SWP_NOMOVE);
        SetWindowPos(GetDlgItem(hWnd, ID_SEPARATOR), nullptr, 0, 0, fw, 2, SWP_NOZORDER | SWP_NOMOVE);
        SetWindowPos(GetDlgItem(hWnd, ID_RESULT),  nullptr, 0, 0, fw, LH + 4, SWP_NOZORDER | SWP_NOMOVE);
        SetWindowPos(GetDlgItem(hWnd, ID_EVALS),   nullptr, 0, 0, fw, LH, SWP_NOZORDER | SWP_NOMOVE);

        int graphH = ch - GRAPH_Y - MY;
        if (graphH < 80) graphH = 80;
        SetWindowPos(GetDlgItem(hWnd, ID_GRAPH),   nullptr, 0, 0, fw, graphH, SWP_NOZORDER | SWP_NOMOVE);

        InvalidateRect(hWnd, nullptr, TRUE);
        break;
    }

    case WM_GETMINMAXINFO:
    {
        MINMAXINFO* mmi = (MINMAXINFO*)lParam;
        mmi->ptMinTrackSize.x = MIN_W + 16;
        mmi->ptMinTrackSize.y = MIN_H + 39;
        return 0;
    }

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

// ---------------------------------------------------------------------------
//  Sample function for plotting
// ---------------------------------------------------------------------------
static bool SampleFunction(const std::string& expr, double a, double b,
                           std::vector<double>& outX, std::vector<double>& outY,
                           double& yMin, double& yMax, int nPts) {
    MathParser parser;
    if (!parser.compile(expr)) return false;

    outX.clear();
    outY.clear();
    outX.reserve(nPts);
    outY.reserve(nPts);

    yMin = 1e300;
    yMax = -1e300;
    bool anyValid = false;

    for (int i = 0; i < nPts; ++i) {
        double t = (double)i / (double)(nPts - 1);
        double x = a + t * (b - a);
        double y = parser.evaluate(x);

        if (std::isfinite(y)) {
            outX.push_back(x);
            outY.push_back(y);
            if (y < yMin) yMin = y;
            if (y > yMax) yMax = y;
            anyValid = true;
        }
    }

    if (!anyValid) return false;

    // Add 10% padding to y range, handle near-constant functions
    double range = yMax - yMin;
    if (range < 1e-12) {
        double pad = std::max(std::abs(yMin) * 0.1, 0.5);
        yMin -= pad;
        yMax += pad;
    } else {
        double pad = range * 0.1;
        yMin -= pad;
        yMax += pad;
    }

    // Ensure y=0 is visible when the function crosses or is near zero
    if (yMin > 0) yMin = -range * 0.05;
    if (yMax < 0) yMax = range * 0.05;

    return true;
}

// ---------------------------------------------------------------------------
//  Compute and populate plot data
// ---------------------------------------------------------------------------
static void DoCompute(HWND hWnd) {
    wchar_t exprBuf[512] = {};
    wchar_t lowerBuf[64] = {};
    wchar_t upperBuf[64] = {};
    wchar_t tolBuf[64]   = {};

    GetWindowText(GetDlgItem(hWnd, ID_EXPR),  exprBuf, 512);
    GetWindowText(GetDlgItem(hWnd, ID_LOWER), lowerBuf, 64);
    GetWindowText(GetDlgItem(hWnd, ID_UPPER), upperBuf, 64);
    GetWindowText(GetDlgItem(hWnd, ID_TOL),   tolBuf,   64);

    int methodSel = ComboBox_GetCurSel(GetDlgItem(hWnd, ID_METHOD));

    std::string expr  = WideToUTF8(exprBuf);
    double a = wcstod(lowerBuf, nullptr);
    double b = wcstod(upperBuf, nullptr);
    double tol = wcstod(tolBuf, nullptr);
    if (tol <= 0.0) tol = 1e-8;

    IntegrationMethod method;
    switch (methodSel) {
    case 1: method = IntegrationMethod::Simpson;     break;
    case 2: method = IntegrationMethod::Trapezoidal; break;
    default:method = IntegrationMethod::Adaptive;    break;
    }

    if (expr.empty()) {
        SetWindowText(GetDlgItem(hWnd, ID_RESULT), L"错误: 请输入被积函数");
        SetWindowText(GetDlgItem(hWnd, ID_EVALS),  L"");
        g_plot.valid = false;
        InvalidateRect(GetDlgItem(hWnd, ID_GRAPH), nullptr, TRUE);
        return;
    }

    MathParser parser;
    if (!parser.compile(expr)) {
        SetWindowText(GetDlgItem(hWnd, ID_RESULT), L"错误: 表达式语法错误");
        SetWindowText(GetDlgItem(hWnd, ID_EVALS),  L"");
        g_plot.valid = false;
        InvalidateRect(GetDlgItem(hWnd, ID_GRAPH), nullptr, TRUE);
        return;
    }

    auto f = [&](double x) { return parser.evaluate(x); };
    IntegrationResult result = integrate(f, a, b, method, 1000, tol);

    // Format and display results
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(12) << result.result;
    std::string resultStr = "结果:  " + oss.str();
    SetWindowText(GetDlgItem(hWnd, ID_RESULT), UTF8ToWide(resultStr).c_str());

    std::ostringstream oss2;
    oss2 << "计算方法: " << result.method_name
         << "    |    函数求值次数: " << result.evaluations;
    SetWindowText(GetDlgItem(hWnd, ID_EVALS), UTF8ToWide(oss2.str()).c_str());

    // Populate plot data
    double plotA = (a <= b) ? a : b;
    double plotB = (a <= b) ? b : a;

    g_plot.valid = false;
    g_plot.a = a;
    g_plot.b = b;
    g_plot.method = method;

    // Dense curve samples (~400 points)
    if (SampleFunction(expr, plotA, plotB, g_plot.curveX, g_plot.curveY,
                       g_plot.yMin, g_plot.yMax, 400)) {
        // Coarse samples for method visualization
        g_plot.nViz = (method == IntegrationMethod::Adaptive) ? 40 : 40;
        if (method == IntegrationMethod::Simpson && g_plot.nViz % 2 != 0)
            g_plot.nViz++;

        SampleFunction(expr, plotA, plotB, g_plot.vizX, g_plot.vizY,
                       g_plot.yMin, g_plot.yMax, g_plot.nViz + 1);
        // Merge y-range from both samplings (dense sampling already set yMin/yMax)
        // Just record the result
        g_plot.result = result.result;
        g_plot.valid = true;
    }

    // Start animation
    HWND hGraph = GetDlgItem(hWnd, ID_GRAPH);
    if (g_anim.active) {
        KillTimer(hGraph, g_anim.timerId);
    }
    g_anim.active = true;
    g_anim.step = 0;
    g_anim.timerId = SetTimer(hGraph, 1, 25, nullptr);

    InvalidateRect(hGraph, nullptr, TRUE);
}

// ---------------------------------------------------------------------------
//  Nice tick spacing helper
// ---------------------------------------------------------------------------
static double NiceTick(double range, int maxTicks) {
    if (range <= 0) return 1;
    double rough = range / maxTicks;
    double exp = std::pow(10.0, std::floor(std::log10(rough)));
    double mant = rough / exp;
    if (mant <= 1.5)      exp *= 1;
    else if (mant <= 3.5) exp *= 2;
    else if (mant <= 7.5) exp *= 5;
    else                  exp *= 10;
    return exp;
}

// ---------------------------------------------------------------------------
//  Graph window procedure
// ---------------------------------------------------------------------------
static LRESULT CALLBACK GraphWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_TIMER:
        if (g_anim.active) {
            g_anim.step++;
            if (g_anim.step >= AnimState::TOTAL) {
                g_anim.active = false;
                KillTimer(hWnd, g_anim.timerId);
                g_anim.timerId = 0;
            }
            InvalidateRect(hWnd, nullptr, FALSE);
        }
        return 0;

    case WM_DESTROY:
        if (g_anim.timerId) {
            KillTimer(hWnd, g_anim.timerId);
            g_anim.timerId = 0;
            g_anim.active = false;
        }
        return 0;

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        RECT clientRect;
        GetClientRect(hWnd, &clientRect);
        int w = clientRect.right - clientRect.left;
        int h = clientRect.bottom - clientRect.top;

        // Double-buffer
        HDC memDC = CreateCompatibleDC(hdc);
        HBITMAP memBmp = CreateCompatibleBitmap(hdc, w, h);
        HBITMAP oldBmp = (HBITMAP)SelectObject(memDC, memBmp);

        // White background
        HBRUSH whiteBrush = CreateSolidBrush(RGB(255, 255, 255));
        FillRect(memDC, &clientRect, whiteBrush);
        DeleteObject(whiteBrush);

        if (!g_plot.valid) {
            // Draw placeholder text
            SetBkMode(memDC, TRANSPARENT);
            HFONT smallFont = CreateFont(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                         DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                         CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                         DEFAULT_PITCH, L"Microsoft YaHei");
            SelectObject(memDC, smallFont);
            SetTextColor(memDC, RGB(160, 160, 160));
            RECT r = clientRect;
            DrawText(memDC, L"输入函数并点击「计算定积分」以显示图像",
                     -1, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            DeleteObject(smallFont);
        } else {
            // Plot margins
            const int MARGIN_L = 62;
            const int MARGIN_R = 22;
            const int MARGIN_T = 16;
            const int MARGIN_B = 36;
            int plotL = MARGIN_L;
            int plotR = w - MARGIN_R;
            int plotT = MARGIN_T;
            int plotB = h - MARGIN_B;
            int plotW = plotR - plotL;
            int plotH = plotB - plotT;

            if (plotW < 20 || plotH < 20) goto paintDone;

            double dataA = (g_plot.a <= g_plot.b) ? g_plot.a : g_plot.b;
            double dataB = (g_plot.a <= g_plot.b) ? g_plot.b : g_plot.a;
            double dataYMin = g_plot.yMin;
            double dataYMax = g_plot.yMax;

            auto toX = [&](double x) -> int {
                return plotL + (int)((x - dataA) / (dataB - dataA) * plotW);
            };
            auto toY = [&](double y) -> int {
                return plotB - (int)((y - dataYMin) / (dataYMax - dataYMin) * plotH);
            };

            double animProg = g_anim.active ? (double)g_anim.step / AnimState::TOTAL : 1.0;
            double progressX = dataA + animProg * (dataB - dataA);
            bool animDone = (animProg >= 1.0);

            double baselineY = 0.0;
            if (baselineY < dataYMin) baselineY = dataYMin;
            if (baselineY > dataYMax) baselineY = dataYMax;
            int baselinePx = toY(baselineY);

            // ---- Draw grid ----
            HPEN gridPen = CreatePen(PS_DOT, 1, RGB(210, 210, 210));
            SelectObject(memDC, gridPen);

            double xTick = NiceTick(dataB - dataA, 6);
            double xStart = std::ceil(dataA / xTick) * xTick;
            for (double xv = xStart; xv <= dataB + xTick * 0.5; xv += xTick) {
                int px = toX(xv);
                if (px >= plotL && px <= plotR) {
                    MoveToEx(memDC, px, plotT, nullptr);
                    LineTo(memDC, px, plotB);
                }
            }

            double yTick = NiceTick(dataYMax - dataYMin, 6);
            double yStart = std::ceil(dataYMin / yTick) * yTick;
            for (double yv = yStart; yv <= dataYMax + yTick * 0.5; yv += yTick) {
                int py = toY(yv);
                if (py >= plotT && py <= plotB) {
                    MoveToEx(memDC, plotL, py, nullptr);
                    LineTo(memDC, plotR, py);
                }
            }
            DeleteObject(gridPen);

            // ---- Draw method-specific fill area ----
            HPEN fillPen = CreatePen(PS_SOLID, 1, RGB(0, 120, 200));
            HBRUSH fillBrush = CreateSolidBrush(RGB(200, 225, 250));
            SelectObject(memDC, fillPen);
            SelectObject(memDC, fillBrush);

            int nViz = (int)g_plot.vizX.size();
            if (nViz >= 2) {
                if (g_plot.method == IntegrationMethod::Trapezoidal) {
                    // Draw each trapezoid, animated left to right
                    for (int i = 0; i < nViz - 1 && g_plot.vizX[i] < progressX; ++i) {
                        POINT pts[4];
                        pts[0].x = toX(g_plot.vizX[i]);
                        pts[0].y = toY(g_plot.vizY[i]);
                        pts[1].x = toX(g_plot.vizX[i + 1]);
                        pts[1].y = toY(g_plot.vizY[i + 1]);
                        pts[2].x = toX(g_plot.vizX[i + 1]);
                        pts[2].y = baselinePx;
                        pts[3].x = toX(g_plot.vizX[i]);
                        pts[3].y = baselinePx;
                        Polygon(memDC, pts, 4);
                    }
                } else if (g_plot.method == IntegrationMethod::Simpson) {
                    // Draw parabolic segments, animated left to right
                    for (int i = 0; i + 2 < nViz && g_plot.vizX[i] < progressX; i += 2) {
                        double x0 = g_plot.vizX[i];
                        double y0 = g_plot.vizY[i];
                        double y1 = g_plot.vizY[i + 1];
                        double x2 = g_plot.vizX[i + 2];
                        double y2 = g_plot.vizY[i + 2];

                        const int NP = 24;
                        POINT pts[NP + 2];
                        for (int j = 0; j <= NP; ++j) {
                            double t = (double)j / NP;
                            double L0 = (2.0 * t - 1.0) * (t - 1.0);
                            double L1 = 4.0 * t * (1.0 - t);
                            double L2 = t * (2.0 * t - 1.0);
                            double xp = x0 + t * (x2 - x0);
                            double yp = y0 * L0 + y1 * L1 + y2 * L2;
                            pts[j].x = toX(xp);
                            pts[j].y = toY(yp);
                        }
                        pts[NP].x = toX(x2);
                        pts[NP].y = baselinePx;
                        pts[NP + 1].x = toX(x0);
                        pts[NP + 1].y = baselinePx;
                        Polygon(memDC, pts, NP + 2);
                    }
                } else {
                    // Adaptive: fill area under curve, animated left to right
                    int nCurve = (int)g_plot.curveX.size();
                    if (nCurve >= 2) {
                        // Find cutoff index for animation
                        int cutIdx = nCurve;
                        for (int i = 0; i < nCurve; ++i) {
                            if (g_plot.curveX[i] > progressX) { cutIdx = i; break; }
                        }
                        if (cutIdx < 2) cutIdx = 2;

                        std::vector<POINT> pts;
                        pts.reserve(cutIdx + 3);
                        for (int i = 0; i < cutIdx; ++i) {
                            POINT pt;
                            pt.x = toX(g_plot.curveX[i]);
                            pt.y = toY(g_plot.curveY[i]);
                            pts.push_back(pt);
                        }
                        // Interpolate y at progressX for smooth cutoff
                        if (cutIdx < nCurve && cutIdx > 0) {
                            double t = (progressX - g_plot.curveX[cutIdx - 1])
                                     / (g_plot.curveX[cutIdx] - g_plot.curveX[cutIdx - 1]);
                            double yAt = g_plot.curveY[cutIdx - 1]
                                       + t * (g_plot.curveY[cutIdx] - g_plot.curveY[cutIdx - 1]);
                            POINT cp;
                            cp.x = toX(progressX);
                            cp.y = toY(yAt);
                            pts.push_back(cp);
                        }
                        POINT br;
                        br.x = pts.back().x;
                        br.y = baselinePx;
                        pts.push_back(br);
                        POINT bl;
                        bl.x = toX(g_plot.curveX.front());
                        bl.y = baselinePx;
                        pts.push_back(bl);
                        Polygon(memDC, pts.data(), (int)pts.size());
                    }
                }
            }

            DeleteObject(fillPen);
            DeleteObject(fillBrush);

            // ---- Draw axes ----
            HPEN axisPen = CreatePen(PS_SOLID, 2, RGB(60, 60, 60));
            SelectObject(memDC, axisPen);

            // Y-axis (at x = dataA, or at x=0 if visible)
            double yAxisX = (dataA <= 0 && dataB >= 0) ? 0.0 : dataA;
            int yAxisPx = toX(yAxisX);
            MoveToEx(memDC, yAxisPx, plotT, nullptr);
            LineTo(memDC, yAxisPx, plotB);

            // X-axis (at y = baselineY = 0, clamped)
            int xAxisPx = baselinePx;
            MoveToEx(memDC, plotL, xAxisPx, nullptr);
            LineTo(memDC, plotR, xAxisPx);

            // Arrow tips for axes
            // Y-axis arrow
            MoveToEx(memDC, yAxisPx, plotT, nullptr);
            LineTo(memDC, yAxisPx - 4, plotT + 8);
            MoveToEx(memDC, yAxisPx, plotT, nullptr);
            LineTo(memDC, yAxisPx + 4, plotT + 8);
            // X-axis arrow
            MoveToEx(memDC, plotR, xAxisPx, nullptr);
            LineTo(memDC, plotR - 8, xAxisPx - 4);
            MoveToEx(memDC, plotR, xAxisPx, nullptr);
            LineTo(memDC, plotR - 8, xAxisPx + 4);

            DeleteObject(axisPen);

            // ---- Draw tick labels ----
            SetBkMode(memDC, TRANSPARENT);
            HFONT tickFont = CreateFont(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                        CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                        DEFAULT_PITCH, L"Microsoft YaHei");
            SelectObject(memDC, tickFont);
            SetTextColor(memDC, RGB(80, 80, 80));

            // X-axis ticks
            for (double xv = xStart; xv <= dataB + xTick * 0.5; xv += xTick) {
                int px = toX(xv);
                if (px >= plotL && px <= plotR) {
                    MoveToEx(memDC, px, xAxisPx - 4, nullptr);
                    LineTo(memDC, px, xAxisPx + 4);

                    wchar_t buf[32];
                    if (std::abs(xv) < xTick * 0.01) {
                        wsprintf(buf, L"0");
                    } else if (std::abs(xv) >= 1000 || std::abs(xv) < 0.01) {
                        wsprintf(buf, L"%.1e", xv);
                    } else {
                        wsprintf(buf, L"%.4g", xv);
                    }
                    RECT tr = { px - 40, xAxisPx + 5, px + 40, xAxisPx + 22 };
                    DrawText(memDC, buf, -1, &tr, DT_CENTER | DT_TOP | DT_SINGLELINE);
                }
            }

            // Y-axis ticks
            for (double yv = yStart; yv <= dataYMax + yTick * 0.5; yv += yTick) {
                int py = toY(yv);
                if (py >= plotT && py <= plotB) {
                    MoveToEx(memDC, yAxisPx - 4, py, nullptr);
                    LineTo(memDC, yAxisPx + 4, py);

                    wchar_t buf[32];
                    if (std::abs(yv) < yTick * 0.01) {
                        wsprintf(buf, L"0");
                    } else if (std::abs(yv) >= 1000 || std::abs(yv) < 0.01) {
                        wsprintf(buf, L"%.1e", yv);
                    } else {
                        wsprintf(buf, L"%.4g", yv);
                    }
                    RECT tr = { 2, py - 11, yAxisPx - 8, py + 11 };
                    DrawText(memDC, buf, -1, &tr, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
                }
            }

            // ---- Draw smooth function curve on top (animated) ----
            int nCurve = (int)g_plot.curveX.size();
            if (nCurve >= 2) {
                // Count points within animation progress
                int drawTo = nCurve;
                for (int i = 0; i < nCurve; ++i) {
                    if (g_plot.curveX[i] > progressX) { drawTo = i + 1; break; }
                }
                if (drawTo > nCurve) drawTo = nCurve;
                if (drawTo < 2) drawTo = 2;

                HPEN curvePen = CreatePen(PS_SOLID, 2, RGB(220, 50, 50));
                SelectObject(memDC, curvePen);

                std::vector<POINT> pts(drawTo);
                for (int i = 0; i < drawTo; ++i) {
                    pts[i].x = toX(g_plot.curveX[i]);
                    pts[i].y = toY(g_plot.curveY[i]);
                }

                HRGN clipRgn = CreateRectRgn(plotL, plotT, plotR, plotB);
                SelectClipRgn(memDC, clipRgn);

                Polyline(memDC, pts.data(), drawTo);

                SelectClipRgn(memDC, nullptr);
                DeleteObject(clipRgn);
                DeleteObject(curvePen);
            }

            // ---- Draw integral bounds when animation completes ----
            if (animDone) {
                HPEN boundPen = CreatePen(PS_DASH, 1, RGB(100, 100, 100));
                SelectObject(memDC, boundPen);

                int aPx = toX(g_plot.a);
                if (aPx >= plotL && aPx <= plotR) {
                    MoveToEx(memDC, aPx, plotT, nullptr);
                    LineTo(memDC, aPx, plotB);
                }
                int bPx = toX(g_plot.b);
                if (bPx >= plotL && bPx <= plotR) {
                    MoveToEx(memDC, bPx, plotT, nullptr);
                    LineTo(memDC, bPx, plotB);
                }
                DeleteObject(boundPen);

                SetTextColor(memDC, RGB(100, 100, 100));
                if (aPx >= plotL && aPx <= plotR) {
                    RECT ar = { aPx - 20, plotB + 3, aPx + 20, plotB + 20 };
                    DrawText(memDC, L"a", -1, &ar, DT_CENTER | DT_TOP | DT_SINGLELINE);
                }
                if (bPx >= plotL && bPx <= plotR) {
                    RECT br2 = { bPx - 20, plotB + 3, bPx + 20, plotB + 20 };
                    DrawText(memDC, L"b", -1, &br2, DT_CENTER | DT_TOP | DT_SINGLELINE);
                }
            }

            // ---- Method label in top-right corner ----
            const wchar_t* methodLabel = L"";
            switch (g_plot.method) {
            case IntegrationMethod::Trapezoidal: methodLabel = L"梯形法"; break;
            case IntegrationMethod::Simpson:     methodLabel = L"辛普森法"; break;
            case IntegrationMethod::Adaptive:    methodLabel = L"自适应法"; break;
            }
            SetTextColor(memDC, RGB(60, 60, 60));
            {
                RECT mr = { plotR - 100, plotT + 4, plotR - 4, plotT + 22 };
                DrawText(memDC, methodLabel, -1, &mr, DT_RIGHT | DT_TOP | DT_SINGLELINE);
            }

            DeleteObject(tickFont);
        }

paintDone:
        // Blit to screen
        BitBlt(hdc, 0, 0, w, h, memDC, 0, 0, SRCCOPY);
        SelectObject(memDC, oldBmp);
        DeleteObject(memBmp);
        DeleteDC(memDC);
        EndPaint(hWnd, &ps);
        return 0;
    }

    case WM_ERASEBKGND:
        return 1; // handled by WM_PAINT
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

// ---------------------------------------------------------------------------
//  Helpers
// ---------------------------------------------------------------------------
static void CentreWindow(HWND hWnd, int cx, int cy) {
    RECT rc;
    GetWindowRect(GetDesktopWindow(), &rc);
    int x = (rc.right - rc.left - cx) / 2;
    int y = (rc.bottom - rc.top - cy) / 2;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    SetWindowPos(hWnd, nullptr, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}

static void CreateLabel(HWND parent, const wchar_t* text, int x, int y, int w, int h, int id) {
    CreateWindowEx(0, L"STATIC", text,
                   WS_CHILD | WS_VISIBLE | SS_LEFT,
                   x, y, w, h,
                   parent, (HMENU)(INT_PTR)id, GetModuleHandle(nullptr), nullptr);
}

static HWND CreateEdit(HWND parent, int x, int y, int w, int h, int id) {
    return CreateWindowEx(
        WS_EX_CLIENTEDGE, L"EDIT", L"",
        WS_CHILD | WS_VISIBLE | ES_LEFT | ES_AUTOHSCROLL,
        x, y, w, h,
        parent, (HMENU)(INT_PTR)id, GetModuleHandle(nullptr), nullptr);
}

static HWND CreateCombo(HWND parent, int x, int y, int w, int h, int id) {
    return CreateWindowEx(
        0, L"COMBOBOX", L"",
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_VSCROLL,
        x, y, w, h + 120,
        parent, (HMENU)(INT_PTR)id, GetModuleHandle(nullptr), nullptr);
}
